<div></div>
<div class="topicos-banner spriteFull"></div>
<div class="clear topicos-listado-container">
	<div class="topicos-listado-columna">
<?php
$previous_letter = "";
$i = 1;
$indice = 0;
$partir_en = floor(count($variables['excelsior_topicos_page_lista'])/2);
foreach($variables['excelsior_topicos_page_lista'] as $key => $topico): 
	$current_letter = _transliterate_string(strtoupper(mb_substr($topico->title,0,1)));
	if($current_letter != $previous_letter):

		// Columnas
		if($i >= $partir_en): ?>
	</div>
	<div class="topicos-listado-columna">
		<?php $partir_en = count($variables['excelsior_topicos_page_lista'])+1;
		endif; ?>
<?php echo ($i>1)?"</ul>":""; ?>
            <h4 class="topicos-listado-header">
                <span class="letra_listado"><?php print($current_letter); ?></span>
                <div class="border_gd_listado"></div>
                <div class="clear_gd"></div>
            </h4>
    <div class="border_listado_1"></div>
    <div class="border_listado_2"></div>
    <div class="border_listado_2"></div>
    <span class="border_image"></span>
<ul class="topicos-listado">
		<?php	
		$previous_letter = $current_letter;
	endif; ?>
	<li class="topicos-listado-list-item" id="<?php echo $key%2!=0 || $key[0]==$indice  ?'topicos_listado_list_item_top':'';?>"><a class="topicos-listado-list-item-link" href="<?php print($topico->url); ?>"><?php print($topico->title); ?></a></li>
	<?php
        $indice++;
	$i++;
endforeach; ?>
</ul>
</div>
</div>
